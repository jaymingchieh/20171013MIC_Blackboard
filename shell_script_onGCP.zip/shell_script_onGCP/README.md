# shell_script_onGCP
