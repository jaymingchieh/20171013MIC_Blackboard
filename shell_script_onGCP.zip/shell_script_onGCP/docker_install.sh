curl -sSL https://get.docker.com/ | sh
sudo usermod -a -G docker $USER
sudo reboot

